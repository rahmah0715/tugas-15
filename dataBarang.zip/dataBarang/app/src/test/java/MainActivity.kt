package com.informatika.databarang
import android.content.Intent
import android.os.Bundle
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.informatika.databarang.model.ResponseBarang
import network.koneksi
import ...
class MainActivity:AppCompatActivity(){
    override fun onCreate(savedIntanceState: Bundle?){
        super.onCreate(savedIntanceState)
        setContentView(R.layout.activity_main)
        // setSupportActionBar(findViewById(R.id.toolbar))
        //
        findViewById<FloatingActionButton>(R.id.fab).setonClickListener { view ->
            val i = Intent (this, InserDataActivity::class.java)
            startActivity(i)
        }
       getData()
    }
public fun getData(){
    koneksi.service.getBarang().enqueue (object :callback<ResponseBarang> {
        override fun onFailure(call: call<ResponseBarang>, t: Throwable) {
            log.d("pesan1", t.localizedMessage)
        }

        override fun onResponse(
            call: call<ResponseBarang>,
            response: Response<ResponseBarang>
        ) {
            if (response.isSuccesfull) {
                val dataBody = response.body()
                val datacontent = dataBody!!.data

                override fun onResume(){
                    super.onResume()
                    getData()
                }
            }
        }
    }
           })
        }

